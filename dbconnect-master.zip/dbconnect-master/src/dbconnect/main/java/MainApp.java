package dbconnect.main.java;

import java.lang.System.Logger;
import java.sql.SQLException;
import java.util.Scanner;

import dbconnect.main.java.api.Connector;

public class MainApp {


		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			Connector c  = new Connector();

			try {
				new Connector().conect();
			} catch (SQLException e) { 

				e.printStackTrace();
			}
			
			String menu="";
			menu="1. Mostrar información sobre los clientes\n"+"2. Mostrar pedidos por importe (precio) decreciente con la siguiente información:\n"+
			"3. Añadir cliente\n"+"4. Actualizar un cliente existente\n"+"5. Eliminar cliente\n"+"6. Añadir Pedido\n"+
					"7. Incluir Líneas de pedido a un pedido existente en estado Procesando\n";
			System.out.println(menu);
			
			System.out.println("Dime una opcion:");
			Integer opcion = Integer.valueOf(sc.nextLine());
			
				while(opcion != 8) {
					if(opcion == 1) {
						try {
							System.out.println(c.mostrarInfoCliente());
						} catch (ClassNotFoundException | SQLException e) {
							e.printStackTrace();
						}
					}else if(opcion == 2) {
						try {
							System.out.println(c.mostrarInfoPedidos());
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
					}else if(opcion == 3) {
						System.out.println("Introduce el nombre:");
						String nombre = sc.nextLine();
						System.out.println("Introduce el apellido:");
						String apellido = sc.nextLine();
						System.out.println("Introduce el email:");
						String email = sc.nextLine();
						System.out.println("Introduce el fechaNacimiento:");
						String fechaNacimiento = sc.nextLine();
						System.out.println("Introduce el genero:");
						String genero = sc.nextLine();

						try {
							c.anniadirCliente(nombre, apellido, email, fechaNacimiento, genero);
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}else if(opcion == 4) {
						System.out.println("Introduce el email nuevo:");
						String email = sc.nextLine();
						System.out.println("Introduce el email antiguo");
						String emailAntiguo = sc.nextLine();
						try {
							c.actualizarCliente(email, emailAntiguo
									);
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}else if(opcion == 5) {
						System.out.println("Introduce el id:");
						Integer id =Integer.valueOf(sc.nextLine());
						try {
							c.eliminarCliente(id);
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}else if(opcion == 6) {
						System.out.println("Dime el id:");
						Integer id = Integer.valueOf(sc.nextLine());
						System.out.println("Dime el codigo");
						String codigo = sc.nextLine();
						System.out.println("Dime el estado");
						String status = sc.nextLine();
						System.out.println("Dime el idCliente");
						Integer idCliente = Integer.valueOf(sc.nextLine());
						try {
							c.anniadirPedido(id, codigo, status, idCliente);
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}else if(opcion == 7) {
						System.out.println("Dime el id:");
						Integer id = Integer.valueOf(sc.nextLine());
						System.out.println("Dime el codigo");
						String codigo = sc.nextLine();
						System.out.println("Dime el nombre del producto");
						String nombreProducto = sc.nextLine();
						System.out.println("Dime el id del pedido:");
						Integer idPedido = Integer.valueOf(sc.nextLine());
						System.out.println("Dime la cantidad:");
						Integer cantidad = Integer.valueOf(sc.nextLine());
						System.out.println("Dime el precio:");
						Integer precio = Integer.valueOf(sc.nextLine());
						try {
							c.anniadirLinea(id, codigo, nombreProducto, idPedido, cantidad, precio);
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
					}
					System.out.println("Dime una opcion:");
					opcion = Integer.valueOf(sc.nextLine());
				}
				
			
		
		}
}
